import java.net.*;
import java.io.*;

public class Server {
    public static void main(String[] args) throws IOException{
        //start server first.

        ServerSocket myServerSocket = new ServerSocket(4999);
        Socket mySocket = myServerSocket.accept();

        System.out.println("Client connected");

        InputStreamReader myInputStreamReader = new InputStreamReader(mySocket.getInputStream());
        BufferedReader myBufferedReader = new BufferedReader(myInputStreamReader);

        String myString = myBufferedReader.readLine();
        System.out.println("Client : " + myString);

        PrintWriter myPrintWriter = new PrintWriter(mySocket.getOutputStream());
        myPrintWriter.println("Yes");
        myPrintWriter.flush();

        //setup database so the user's information can be stored and interacted with

    }

}
