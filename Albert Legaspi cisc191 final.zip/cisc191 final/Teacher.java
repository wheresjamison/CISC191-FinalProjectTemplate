import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Teacher extends User implements edu{

    String schoolName;

    public Teacher(){}
    public Teacher(int phoneNumber, String schoolName){
        this.phoneNumber = phoneNumber;
        this.schoolName = schoolName;
    }

    public static List<Teacher> listOfTea = new ArrayList<>();

    public static void tCreateAndAddToList(User u, String schoolName){
        int pn = u.getPhoneNumber();
        listOfTea.add(new Teacher(pn,schoolName));
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    @Override
    public void createFileOFAllCourses(String c1, String c2, String c3, String c4) {
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\Users\\Jamison-chan\\Desktop\\may cisc191\\allCourses.txt"));
            courses.add(c1);
            courses.add(c2);
            courses.add(c3);
            courses.add(c4);
            for(int i = 0; i<courses.size(); i++){
                bw.write(courses.get(i)+"\n");
            }
            bw.close();
        }catch(Exception e){

        }

    }
