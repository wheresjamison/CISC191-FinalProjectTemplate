import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ForgotPasswordPage{
    /**page will open and ask question to verify user
     * once verified, user will be able to create password
     * new password will be updated through myjdbc class
     * */

    private static JPanel forgotPasswordPanel;
    private static JLabel whatIsYourEmailPanel;
    private static JTextField whatEmailText;
    private static JLabel secretQuestion;
    private static JTextField secretAnswer;
    private static JLabel newPasswordLabel;
    private static JTextField newPasswordText;
    private static JButton passwordDoneButton;
    private static JLabel statusNewPasswordLabel;

    public static void main(String[] args) {
        JFrame frameForgotPassword = new JFrame();
        frameForgotPassword.setSize(300,400);
        frameForgotPassword.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        forgotPasswordPanel = new JPanel();
        frameForgotPassword.add(forgotPasswordPanel);
        forgotPasswordPanel.setLayout(null);

        //forgot password page
        ActionListener passwordDoneListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String email = whatEmailText.getText();
                String answer = secretAnswer.getText();
                String password = newPasswordText.getText();

                System.out.println("Done Button Clicked");
                //check answer to change password
                String resultNewPassword = User.checkAnswer(email,answer,password); //fix this in a moment

                statusNewPasswordLabel.setText(resultNewPassword);

                System.out.println(resultNewPassword);

                if(resultNewPassword == "New password has been set"){
                    frameForgotPassword.setVisible(false);
                }
            }
        };

        whatIsYourEmailPanel = new JLabel("What is your email?");
        whatIsYourEmailPanel.setBounds(10,20,165,25);
        forgotPasswordPanel.add(whatIsYourEmailPanel);

        whatEmailText = new JTextField(20);
        whatEmailText.setBounds(10,50,165,25);
        forgotPasswordPanel.add(whatEmailText);

        secretQuestion = new JLabel("What is your favorite color?");
        secretQuestion.setBounds(10,80,165,25);
        forgotPasswordPanel.add(secretQuestion);

        secretAnswer = new JTextField(20);
        secretAnswer.setBounds(10,110,165,25);
        forgotPasswordPanel.add(secretAnswer);

        newPasswordLabel = new JLabel("Create a new Password");
        newPasswordLabel.setBounds(10,140,165,25);
        forgotPasswordPanel.add(newPasswordLabel);

        newPasswordText = new JTextField(20);
        newPasswordText.setBounds(10,170,165,25);
        forgotPasswordPanel.add(newPasswordText);

        statusNewPasswordLabel = new JLabel("");
        statusNewPasswordLabel.setBounds(10,170,165,25);
        forgotPasswordPanel.add(statusNewPasswordLabel);

        passwordDoneButton = new JButton("Done");
        passwordDoneButton.setBounds(10,200,80,25);
        passwordDoneButton.addActionListener(passwordDoneListener);
        forgotPasswordPanel.add(passwordDoneButton);

        frameForgotPassword.setVisible(true);
    }

}
