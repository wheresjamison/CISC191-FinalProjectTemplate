import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class Personal extends User{

    static boolean privacyStatus;
    static void privacyToggle(){
        if(!privacyStatus){
            //do not show on list
        }
        //show on list
    }

    public Personal(){}
    public Personal(int phoneNumber, boolean privacyStatus){
        this.phoneNumber = phoneNumber;
        this.privacyStatus = privacyStatus;
    }

    public static List<Personal> listOfPer = new ArrayList<>();

    public static void pCreateAndAddToList(User u, boolean privacyStatus){
        int pn = u.getPhoneNumber();
        listOfPer.add(new Personal(pn,privacyStatus));
    }

    public static boolean isPrivacyStatus() {
        return privacyStatus;
    }

    public static void setPrivacyStatus(boolean privacyStatus) {
        Personal.privacyStatus = privacyStatus;
    }
}
