import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class Student extends User implements edu{

    static double GPA;
    static String schoolName;

    String course1,course2,course3,course4;
    String grade1, grade2, grade3, grade4;

    static void calculateGPA(char g1, char g2, char g3, char g4){
        int g = 0;
        char[] listGrades = {g1,g2,g3,g4};
        for(int L = 0; L<4; L++) {
            if(listGrades[L]=='a'){
                g=g+4;
            }
            if(listGrades[L]=='b'){
                g=g+3;
            }
            if(listGrades[L]=='c'){
                g=g+2;
            }
            if(listGrades[L]=='d'){
                g=g+1;
            }
            if(listGrades[L]=='f'){
                g=g=0;
            }
        }
        GPA = g/4;
    }

    public Student() {
    }

    public Student(int phoneNumber, String schoolName,
                   String c1, String c2, String c3, String c4,
                   String g1, String g2, String g3, String g4, double GPA){
        this.phoneNumber = phoneNumber;
        this.schoolName = schoolName;
        this.course1 = c1;
        this.course2 = c2;
        this.course3 = c3;
        this.course4 = c4;
        this.grade1 = g1;
        this.grade2 = g2;
        this.grade3 = g3;
        this.grade4 = g4;
    }
    public static List<Student> listOfStu = new ArrayList<>();
    public static void sCreateAndAddToList(User u, String schoolName,
                                           String c1, String c2, String c3, String c4,
                                           String g1, String g2, String g3, String g4){
        int pn = u.getPhoneNumber();
        calculateGPA(g1.charAt(0),g2.charAt(0),g3.charAt(0),g4.charAt(0));
        listOfStu.add(new Student(pn, schoolName, c1,c2,c3,c4,g1,g2,g3,g4,GPA));
    }



    public static double getGPA() {
        return GPA;
    }

    public static void setGPA(double GPA) {
        Student.GPA = GPA;
    }

    public static String getSchoolName() {
        return schoolName;
    }

    public static void setSchoolName(String schoolName) {
        Student.schoolName = schoolName;
    }

    @Override
    public void createFileOFAllCourses(String c1, String c2, String c3, String c4) {
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\Users\\Jamison-chan\\Desktop\\may cisc191\\allCourses.txt"));
            courses.add(c1);
            courses.add(c2);
            courses.add(c3);
            courses.add(c4);
            for(int i = 0; i<courses.size(); i++){
                bw.write(courses.get(i)+"\n");
            }
            bw.close();
        }catch(Exception e){

        }
    }
}
