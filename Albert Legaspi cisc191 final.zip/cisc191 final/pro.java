public interface pro {
    String getExperience();
    String getPurpose();
    String getIntendedUse();
}
