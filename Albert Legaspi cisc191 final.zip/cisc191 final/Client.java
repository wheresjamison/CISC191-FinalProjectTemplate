import java.net.*;
import java.io.*;
//client
public class Client {
    public static void main(String[] args) throws IOException{
        Socket mySocket = new Socket("localhost",4999);

        PrintWriter myPrintWriter = new PrintWriter(mySocket.getOutputStream());
        myPrintWriter.println("is it working");
        myPrintWriter.flush();

        InputStreamReader myInputStreamReader = new InputStreamReader(mySocket.getInputStream());
        BufferedReader myBufferedReader = new BufferedReader(myInputStreamReader);

        String myString = myBufferedReader.readLine();
        System.out.println("Server : " + myString);
        String s;
        s = String.valueOf(User.listOfUsers);
        System.out.println(s);
    }
}
