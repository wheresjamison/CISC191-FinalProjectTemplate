import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class MyJDBC{

//    public static Connection connection = null;
//    public static Statement statement = null;

    /**find way to read values from database and send them to an arraylist within the user Class
     * this will help not only with login information
     * but once i get to the main page
     *
     * */

    public static void uploadListOfUsersToDB(List<User> users){
        try{
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cisc191-may-userinfo", "root", "Rootpass123!");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("Select * from users");
            for(User u: users){
                try{
                    //without id due to auto incrementing
                    String query1 = "INSERT INTO users(typeuser,firstname,lastname,email,username,password,secretAnswer,age,phoneNumber,birthdayDay,birthdayMonth,birthdayYear,birthdayString)"
                            + " VALUES" +  u.toStringForSQL();
                    statement.executeUpdate(query1);
                }catch(Exception e){
                    e.printStackTrace();
                }
                //u.printUser();
                //System.out.println("--");
                System.out.println(u.toStringForSQL());
            }
        }catch(Exception e){
            e.printStackTrace();
        }

    }

    public static void cleanDuplicates(){
        try{
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cisc191-may-userinfo", "root", "Rootpass123!");
            Statement statement = connection.createStatement();
            String query = "Delete t1 From users t1 \n INNER JOIN users t2 \n WHERE \n t1.id<t2.id AND t1.email = t2.email;";
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public static void testUpload(){
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testjdbc", "root", "Rootpass123!");

            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("Select * from user");

            while (resultSet.next()) {
                System.out.println(resultSet.getString("name"));
            }



        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public static boolean checkExistingUsers(int phoneNumber){
        String phoneNumberString = String.valueOf(phoneNumber);
        boolean userExists = false;
        try{
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cisc191-may-userinfo", "root", "Rootpass123!");
            PreparedStatement preparedStatement = connection.prepareStatement("select * from users phoneNumber = ? ");
            preparedStatement.setString(1,phoneNumberString);
            ResultSet resultset = preparedStatement.executeQuery();
            String pnString;
            if(resultset.next()){
                pnString = resultset.getString("phoneNumeber");
                if(pnString.equals(phoneNumberString)){
                    System.out.println("User already exists");
                    userExists = true;
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return userExists;
    }

    public static void main(String[] args) {
        List<User> userListFromReference = User.createUserList();

        uploadListOfUsersToDB(userListFromReference);

        cleanDuplicates();

    }

}
