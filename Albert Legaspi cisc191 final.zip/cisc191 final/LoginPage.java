import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPage {

    private static JPanel loginPanel;

    private static JLabel userLabel;

    private static JTextField userText;

    private static JLabel passwordLabel;
    private static JTextField passwordText;

    private static JButton loginButton;
    private static JLabel success;

    private static JButton newUserButton;
    private static JButton forgotPasswordButton;

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(300,400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //this will open a new window for the forgot password page, independent from this page. so when the page is closed it will not close the entire program
        ActionListener forgotPasswordListener = new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("forgot password clicked");
                //frameForgotPassword.setVisible(true);
                frame.setVisible(false);
                //currentPage = "forgot pw";
            }
        };

        //this button will log in user. email will be indexed and related to a password, then they will be compared and return a result state of logged in
        ActionListener loginButtonListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("login button clicked");
                String email = userText.getText();
                String password = passwordText.getText();
                //success.setText(User.checkPassword(email,password));
                if(success.getText() == "Password Correct"){
                    //change panel to logged in
                }
            }
        };

        //this will open a new page that will allow user to create a new user depending on usertype.
        ActionListener newUserListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("new user button clicked");
                //frameNewUser.setVisible(true);
                frame.setVisible(false);
            }
        };

        loginPanel = new JPanel();
        frame.add(loginPanel);
        loginPanel.setLayout(null);

        userLabel = new JLabel("Email");
        userLabel.setBounds(10, 20, 165, 25  );
        loginPanel.add(userLabel);

        userText = new JTextField(20);
        userText.setBounds(10,50,165,25);
        loginPanel.add(userText);

        passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(10,80,165,25);
        loginPanel.add(passwordLabel);

        passwordText = new JTextField(20);
        passwordText.setBounds(10,110,165,25);
        loginPanel.add(passwordText);

        forgotPasswordButton = new JButton("forgot password");
        forgotPasswordButton.setBounds(10,140,165,15);
        forgotPasswordButton.addActionListener(forgotPasswordListener);
        loginPanel.add(forgotPasswordButton);

        newUserButton = new JButton("Create Account");
        newUserButton.setBounds(10,160,165,15);
        newUserButton.addActionListener(newUserListener);
        loginPanel.add(newUserButton);

        loginButton = new JButton("Login");
        loginButton.setBounds(10,180,80,25);
        loginButton.addActionListener(loginButtonListener);
        loginPanel.add(loginButton);

        success = new JLabel("");
        success.setBounds(10,200,300,25);
        loginPanel.add(success);

        frame.setVisible(true);
    }
}
