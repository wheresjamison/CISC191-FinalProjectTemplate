import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NewUserPage{

    //new user panel
    private static JPanel newUserPanel;
    private static JLabel selectUserTypeLabel;
    private static JButton studentUserButton,teacherUserButton,businessUserButton,personalUserButton;

    //user stuff
    private static JLabel firstNameLabel;
    private static JTextField firstNameText;
    private static JLabel lastNameLabel;
    private static JTextField lastNameText;
    private static JLabel emailLabel;
    private static JTextField emailText;
    private static JLabel secretQuestionLabel;
    private static JTextField secretAnswerText;
    private static JLabel ageLabel;
    private static JTextField ageText;
    private static JLabel mmddyyLabel;
    private static JTextField mmText, ddText, yyText;
    private static JLabel phoneNumberLabel;
    private static JTextField phoneNumberText;

    //forgot to add password
    private static JLabel passwordCreateLabel;
    private static JTextField passwordCreateText;

    //user type panels

    private static JLabel schoolNameLabel;
    private static JTextField schoolNameText;

    private static JPanel newStudentPanel;
    private static JLabel studentPanelTitle;

    private static JLabel course1Label, course2Label, course3Label, course4Label;
    private static JTextField course1Text, course2Text, course3Text, course4Text;
    private static JTextField course1GradeText, course2GradeText, course3GradeText, course4GradeText;
    private static JLabel yearLabel;
    private static JTextField yearText;

    private static JPanel newTeacherPanel;
    private static JLabel teacherPanelTitle;
    private static JLabel numberOfStudentsLabel;
    private static JTextField numberOfStudentsText;

    private static JPanel newBusinessPanel;
    private static JLabel businessPanelTitle;
    private static JLabel companyNameLabel;
    private static JTextField companyNameText;

    private static JPanel newPersonalPanel;
    private static JLabel personalPanelTitle;
    private static JButton privacyButton;
    static boolean privacyToggle = true;

    private static JButton createNewUserButton;

    private static String typeUser;

    /** on open, there will be a select page to determine what type of users (student,teacher,ect)
     * on selection of type user, it will open a new window that includes text fields to input all the information
     * on submission, information will be checked to see if user is already existing 
     * if user exists, user will not be allowed to create account
     * if user does not exist, user will be created and information will be sent to myjdbc to add to database
     * */

    public static void main(String[] args) {
        JFrame frameNewUser = new JFrame();
        frameNewUser.setSize(300,400);
        frameNewUser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        newUserPanel = new JPanel();
        frameNewUser.add(newUserPanel);
        newUserPanel.setLayout(null);

        //new user
        selectUserTypeLabel = new JLabel("Select your user type below: ");
        selectUserTypeLabel.setBounds(10,20,165,25);
        newUserPanel.add(selectUserTypeLabel);


        //setup frames and panels for each user type
        JFrame frameCreateStudent = new JFrame();
        JFrame frameCreateTeacher = new JFrame();
        JFrame frameCreateBusiness = new JFrame();
        JFrame frameCreatePersonal = new JFrame();

        frameCreateStudent.setSize(300,700);
        frameCreateTeacher.setSize(300,400);
        frameCreateBusiness.setSize(300,400);
        frameCreatePersonal.setSize(300,400);
        frameCreateStudent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameCreateTeacher.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameCreateBusiness.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameCreatePersonal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        newStudentPanel = new JPanel();
        newTeacherPanel = new JPanel();
        newBusinessPanel = new JPanel();
        newPersonalPanel = new JPanel();

        frameCreateStudent.add(newStudentPanel);
        newStudentPanel.setLayout(null);
        frameCreateTeacher.add(newTeacherPanel);
        newTeacherPanel.setLayout(null);
        frameCreateBusiness.add(newBusinessPanel);
        newBusinessPanel.setLayout(null);
        frameCreatePersonal.add(newPersonalPanel);
        newPersonalPanel.setLayout(null);

        //user
        firstNameLabel = new JLabel("First name:");
        firstNameLabel.setBounds(10,40,80,25);
        firstNameText = new JTextField(20);
        firstNameText.setBounds(90,40,80,25);

        lastNameLabel = new JLabel("Last name:");
        lastNameLabel.setBounds(10,70,80,25);
        lastNameText = new JTextField(20);
        lastNameText.setBounds(90,70,80,25);

        emailLabel = new JLabel("Email:");
        emailLabel.setBounds(10,100,80,25);
        emailText = new JTextField(20);
        emailText.setBounds(90,100,80,25);

        secretQuestionLabel = new JLabel("What is your favorite Color?");
        secretQuestionLabel.setBounds(10,130,180,25);
        secretAnswerText = new JTextField(20);
        secretAnswerText.setBounds(180,130,80,25);

        ageLabel = new JLabel("Age:");
        ageLabel.setBounds(10,160,80,25);
        ageText = new JTextField(20);
        ageText.setBounds(90,160,80,25);

        mmddyyLabel = new JLabel("mm/dd/yy:");
        mmddyyLabel.setBounds(10,190,80,25);
        mmText = new JTextField(20);
        mmText.setBounds(10,220,30,25);
        ddText = new JTextField(20);
        ddText.setBounds(40,220,30,25);
        yyText = new JTextField(20);
        yyText.setBounds(70,220,30,25);

        phoneNumberLabel = new JLabel("Phone number");
        phoneNumberLabel.setBounds(10,250,100,25);
        phoneNumberText = new JTextField(20);
        phoneNumberText.setBounds(100,250,80,25);

        passwordCreateLabel = new JLabel("Set password");
        passwordCreateLabel.setBounds(10,280,100,25);
        passwordCreateText = new JTextField(20);
        passwordCreateText.setBounds(100,280,100,25);

        ActionListener studentAction = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameCreateStudent.setVisible(true);
                newStudentPanel.add(firstNameLabel); newStudentPanel.add(firstNameText);
                newStudentPanel.add(lastNameLabel); newStudentPanel.add(lastNameText);
                newStudentPanel.add(emailLabel); newStudentPanel.add(emailText);
                newStudentPanel.add(secretQuestionLabel); newStudentPanel.add(secretAnswerText);
                newStudentPanel.add(ageLabel); newStudentPanel.add(ageText);
                newStudentPanel.add(mmddyyLabel);
                newStudentPanel.add(mmText); newStudentPanel.add(ddText); newStudentPanel.add(yyText);
                newStudentPanel.add(phoneNumberLabel); newStudentPanel.add(phoneNumberText);
                newStudentPanel.add(schoolNameLabel); newStudentPanel.add(schoolNameText);
                newStudentPanel.add(passwordCreateLabel); newStudentPanel.add(passwordCreateText);

                newStudentPanel.add(createNewUserButton);

                typeUser = "Student";

            }
        };

        ActionListener teacherAction = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                frameCreateTeacher.setVisible(true);

                newTeacherPanel.add(firstNameLabel); newTeacherPanel.add(firstNameText);
                newTeacherPanel.add(lastNameLabel); newTeacherPanel.add(lastNameText);
                newTeacherPanel.add(emailLabel); newTeacherPanel.add(emailText);
                newTeacherPanel.add(secretQuestionLabel); newTeacherPanel.add(secretAnswerText);
                newTeacherPanel.add(ageLabel); newTeacherPanel.add(ageText);
                newTeacherPanel.add(mmddyyLabel);
                newTeacherPanel.add(mmText); newTeacherPanel.add(ddText); newTeacherPanel.add(yyText);
                newTeacherPanel.add(phoneNumberLabel); newTeacherPanel.add(phoneNumberText);
                newTeacherPanel.add(schoolNameLabel); newTeacherPanel.add(schoolNameText);
                newTeacherPanel.add(passwordCreateLabel);newTeacherPanel.add(passwordCreateText);

                newTeacherPanel.add(createNewUserButton);

                typeUser = "Teacher";
            }
        };

        ActionListener businessAction = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameCreateBusiness.setVisible(true);

                newBusinessPanel.add(firstNameLabel); newBusinessPanel.add(firstNameText);
                newBusinessPanel.add(lastNameLabel); newBusinessPanel.add(lastNameText);
                newBusinessPanel.add(emailLabel); newBusinessPanel.add(emailText);
                newBusinessPanel.add(secretQuestionLabel); newBusinessPanel.add(secretAnswerText);
                newBusinessPanel.add(ageLabel); newBusinessPanel.add(ageText);
                newBusinessPanel.add(mmddyyLabel);
                newBusinessPanel.add(mmText); newBusinessPanel.add(ddText); newBusinessPanel.add(yyText);
                newBusinessPanel.add(phoneNumberLabel); newBusinessPanel.add(phoneNumberText);
                newBusinessPanel.add(passwordCreateLabel);newBusinessPanel.add(passwordCreateText);

                newBusinessPanel.add(createNewUserButton);

                typeUser = "Business";
            }
        };

        ActionListener personalAction = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameCreatePersonal.setVisible(true);

                newPersonalPanel.add(firstNameLabel); newPersonalPanel.add(firstNameText);
                newPersonalPanel.add(lastNameLabel); newPersonalPanel.add(lastNameText);
                newPersonalPanel.add(emailLabel); newPersonalPanel.add(emailText);
                newPersonalPanel.add(secretQuestionLabel); newPersonalPanel.add(secretAnswerText);
                newPersonalPanel.add(ageLabel); newPersonalPanel.add(ageText);
                newPersonalPanel.add(mmddyyLabel);
                newPersonalPanel.add(mmText); newPersonalPanel.add(ddText); newPersonalPanel.add(yyText);
                newPersonalPanel.add(phoneNumberLabel); newPersonalPanel.add(phoneNumberText);
                newPersonalPanel.add(passwordCreateLabel); newPersonalPanel.add(passwordCreateText);

                newPersonalPanel.add(createNewUserButton);

                typeUser = "Personal";

            }
        };

        studentUserButton = new JButton("Student");
        studentUserButton.setBounds(10,50,100,25);
        studentUserButton.addActionListener(studentAction);
        newUserPanel.add(studentUserButton);

        teacherUserButton = new JButton("Teacher");
        teacherUserButton.setBounds(140,50,100,25);
        teacherUserButton.addActionListener(teacherAction);
        newUserPanel.add(teacherUserButton);

        businessUserButton = new JButton("Business");
        businessUserButton.setBounds(10,80,100,25);
        businessUserButton.addActionListener(businessAction);
        newUserPanel.add(businessUserButton);

        personalUserButton = new JButton("Personal");
        personalUserButton.setBounds(140,80,100,25);
        personalUserButton.addActionListener(personalAction);
        newUserPanel.add(personalUserButton);

        //frame for user types
        //edu
        schoolNameLabel = new JLabel("School: ");
        schoolNameText = new JTextField(20);
        schoolNameLabel.setBounds(10,310,80,25);
        schoolNameText.setBounds(90,310,80,25);

        //new student
        studentPanelTitle = new JLabel("Welcome New Student!");
        studentPanelTitle.setBounds(10,10,160,25);
        newStudentPanel.add(studentPanelTitle);

        JLabel coursesLabel = new JLabel("                     :  Course Names  :  Grades :");
        coursesLabel.setBounds(10,340,300,25);
        newStudentPanel.add(coursesLabel);

        course1Label = new JLabel("Course 1:");
        course2Label = new JLabel("Course 2:");
        course3Label = new JLabel("Course 3:");
        course4Label = new JLabel("Course 4:");
        course1Text = new JTextField(40);
        course2Text = new JTextField(40);
        course3Text = new JTextField(40);
        course4Text = new JTextField(40);
        course1GradeText = new JTextField(30);
        course2GradeText = new JTextField(30);
        course3GradeText = new JTextField(30);
        course4GradeText = new JTextField(30);

        //add 60 to the y
        course1Label.setBounds(10,370,80,25);
        course2Label.setBounds(10,400,80,25);
        course3Label.setBounds(10,430,80,25);
        course4Label.setBounds(10,460,80,25);
        course1Text.setBounds(90,370,80,25);
        course2Text.setBounds(90,400,80,25);
        course3Text.setBounds(90,430,80,25);
        course4Text.setBounds(90,460,80,25);
        course1GradeText.setBounds(180,370,30,25);
        course2GradeText.setBounds(180,400,30,25);
        course3GradeText.setBounds(180,430,30,25);
        course4GradeText.setBounds(180,460,30,25);

        newStudentPanel.add(course1Label);
        newStudentPanel.add(course2Label);
        newStudentPanel.add(course3Label);
        newStudentPanel.add(course4Label);
        newStudentPanel.add(course1Text);
        newStudentPanel.add(course2Text);
        newStudentPanel.add(course3Text);
        newStudentPanel.add(course4Text);
        newStudentPanel.add(course1GradeText);
        newStudentPanel.add(course2GradeText);
        newStudentPanel.add(course3GradeText);
        newStudentPanel.add(course4GradeText);

        /**
         * create user button for student
         */

        //new teacher
        teacherPanelTitle = new JLabel("Welcome new Teacher!");
        teacherPanelTitle.setBounds(10,10,160,25);
        newTeacherPanel.add(teacherPanelTitle);

        //new business person
        businessPanelTitle = new JLabel("Welcome new Business user!");
        businessPanelTitle.setBounds(10,10,160,25);
        newBusinessPanel.add(businessPanelTitle);

        //280, just changed to 310
        companyNameLabel = new JLabel("Company: ");
        companyNameText = new JTextField(20);
        companyNameLabel.setBounds(10,310,80,25);
        companyNameText.setBounds(90,310,80,25);
        newBusinessPanel.add(companyNameLabel);
        newBusinessPanel.add(companyNameText);

        //new personal user

        ActionListener privacyListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(privacyToggle==true){
                    privacyToggle = false;
                    privacyButton.setText("Private");
                } else {
                    privacyToggle = true;
                    privacyButton.setText("Public");
                }
            }
        };

        personalPanelTitle = new JLabel("Welcome new User!");
        personalPanelTitle.setBounds(10,10,165,25);
        newPersonalPanel.add(personalPanelTitle);
        privacyButton = new JButton("Public");
        privacyButton.setBounds(10,310,80,25);
        privacyButton.addActionListener(privacyListener);
        newPersonalPanel.add(privacyButton);

        //create user button.

        ActionListener createUserListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fn,ln, em, pn, mm, dd, yy, age, sa, pw, tu;
                fn = firstNameText.getText();
                ln = lastNameText.getText();
                em = emailText.getText();
                pn = phoneNumberText.getText();
                mm = mmText.getText();
                dd = ddText.getText();
                yy = yyText.getText();
                age = ageText.getText();
                sa = secretAnswerText.getText();
                pw = passwordCreateText.getText();
                tu = typeUser;
                User.Type type = User.Type.valueOf(tu);
                User newUser = new User(type, fn,ln,em,pw,sa,Integer.valueOf(age),Integer.valueOf(pn),Integer.valueOf(dd),Integer.valueOf(mm),Integer.valueOf(yy));

                if(typeUser == "Student"){
                    //save user information in to a 2 dimensional array
                    //userinfo[i][j] i will be the user index, and j will contain all the information in a list
                    //logininfo[i][j] i is user index, j will be user, password, secret info
                    String sn,c1,c2,c3,c4,g1,g2,g3,g4;
                    sn = schoolNameText.getText();
                    c1 = course1Text.getText();
                    c2 = course2Text.getText();
                    c3 = course3Text.getText();
                    c4 = course4Text.getText();
                    g1 = course1GradeText.getText();
                    g2 = course2GradeText.getText();
                    g3 = course1GradeText.getText();
                    g4 = course4GradeText.getText();

                    Student.sCreateAndAddToList(newUser,sn,
                            c1,c2,c3,c4,
                            g1,g2,g3,g4);
                }
                if(typeUser == "Teacher"){
                    String schoolName = schoolNameText.getText();
                    Teacher.tCreateAndAddToList(newUser, schoolName);

                }
                if(typeUser == "Business"){
                    String company = companyNameText.getText();
                    Business.bCreateAndAddToList(newUser, company);
                }
                if(typeUser == "Personal"){
                    boolean priv = privacyToggle;
                    Personal.pCreateAndAddToList(newUser, priv);
                }
                //this will add userName to the list of user file
                /**
                 try{
                 BufferedWriter listOfUsers = new BufferedWriter(
                 new FileWriter("C:\\Users\\legas\\Desktop\\apriljavafilefolder\\projectInfo.txt"));
                 listOfUsers.write(User.listOfUserNames.get(0));
                 }catch(Exception ex){
                 System.out.println("ex");
                 }
                 */
            }
        };

        int yPlacementForButton = 0; //520 for student,310 for teacher, business and personal
        createNewUserButton = new JButton("Create Account");
        createNewUserButton.setBounds(10,yPlacementForButton,80,25);
        //add to panel depending on what is open
        //create ActionListener
        createNewUserButton.addActionListener(createUserListener);

        frameNewUser.setVisible(true);
    }
}
