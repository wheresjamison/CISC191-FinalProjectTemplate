import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

public class Business extends User{

    String companyName;

    public Business(){}
    public Business(int phoneNumber, String companyName){
        this.phoneNumber = phoneNumber;
        this.companyName = companyName;
    }

    public static List<Business> listOfBis = new ArrayList<>();

    public static void bCreateAndAddToList(User u, String companyName){
        int pn = u.getPhoneNumber();
        listOfBis.add(new Business(pn, companyName));
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}