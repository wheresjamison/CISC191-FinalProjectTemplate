import com.sun.media.jfxmediaimpl.MediaUtils;
import sun.security.krb5.internal.APOptions;

import java.io.BufferedReader;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class User {

    //send to student class
    public enum GradeValues {
        A(4.0), B(3.0), C(2.0), D(1.0), F(0.0);
        final double numberValue;

        GradeValues(double numberValue) {
            this.numberValue = numberValue;
        }
    }

    static String[] birthMonthName = {"January", "February",
            "March", "April", "May",
            "June", "July", "August",
            "September", "October", "November",
            "December"};

    public enum Type {
        STUDENT,
        TEACHER,
        BUSINESS,
        PERSONAL;
    }

    Type typeUser;
    String firstName, lastName, email;
    String userName, password, secretAnswer;
    int userID;
    int age, phoneNumber;

    int birthdayNum, birthYearNum, birthMonthNum;
    String birthdayString;

    public User() {
    }

    @Override
    public String toString() {
        return "User{" +
                "typeUser=" + typeUser +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", userName='" + userName + '\'' +
                ", userID='" + userID + '\'' +
                ", password='" + password + '\'' +
                ", secretAnswer='" + secretAnswer + '\'' +
                ", age=" + age +
                ", phoneNumber=" + phoneNumber +
                ", birthdayNum=" + birthdayNum +
                ", birthMonthNum=" + birthMonthNum +
                ", birthYearNum=" + birthYearNum +
                ", birthdayString='" + birthdayString + '\'' +
                '}';
    }

    public String toStringForSQL(){
        return ("('"+typeUser + "','"+
                firstName +"','"+lastName +"','"+ email +"','"+
                userName +"','" + password +"','"+ secretAnswer +"','"+
                age +"','"+ phoneNumber +"','"+
                birthdayNum+"','"+ birthMonthNum+"','"+ birthYearNum +"','"+
                birthdayString +"')");
    }

    public User(Type typeUser,
                String firstName, String lastName, String email,
                String password, String secretAnswer,
                int age, int phoneNumber,
                int birthdayNum, int birthMonthNum, int birthYearNum) {
        //this.userID = listOfUsers.size()+1; //5
        this.typeUser = typeUser; //0
        this.firstName = firstName; //1
        this.lastName = lastName; //2
        this.email = email; //3

        this.userName = setUserName(firstName, lastName, phoneNumber, typeUser); //4

        this.password = password; //6
        this.secretAnswer = secretAnswer; //7

        this.age = age; //8
        this.phoneNumber = phoneNumber; //9
        this.birthdayNum = birthdayNum; //10
        this.birthYearNum = birthYearNum; //11
        this.birthMonthNum = birthMonthNum; //12

        this.birthdayString = convertBirthNumToString(birthMonthNum,birthdayNum,birthYearNum); //13
    }

    static int convertPhoneNumberToUID(int phoneNumber){
        return phoneNumber-1;
    }

    public Type getTypeUser() {
        return typeUser;
    }

    public void setTypeUser(Type typeUser) {
        this.typeUser = typeUser;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSecretAnswer() {
        return secretAnswer;
    }

    public void setSecretAnswer(String secretAnswer) {
        this.secretAnswer = secretAnswer;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getBirthdayNum() {
        return birthdayNum;
    }

    public void setBirthdayNum(int birthdayNum) {
        this.birthdayNum = birthdayNum;
    }

    public int getBirthYearNum() {
        return birthYearNum;
    }

    public void setBirthYearNum(int birthYearNum) {
        this.birthYearNum = birthYearNum;
    }

    public int getBirthMonthNum() {
        return birthMonthNum;
    }

    public void setBirthMonthNum(int birthMonthNum) {
        this.birthMonthNum = birthMonthNum;
    }

    public String getBirthdayString() {
        return birthdayString;
    }

    public void setBirthdayString(String birthdayString) {
        this.birthdayString = birthdayString;
    }


    /** unused sorting things*/

    interface CheckUser {
        boolean test(User u);
    }

    static class CheckUserForStudentDiscounts implements User.CheckUser {

        @Override
        public boolean test(User u) {
            return u.typeUser == User.Type.STUDENT;
        }
    }

    public static void printUsersAboveAge(List<User> users,
                                          int age){
        for(User u: users){
            if(u.getAge() >= age){
                u.printUser();
            }
            else{
                System.out.println("No users found");
            }
        }
    }

    public static void printUsersWIAgeRange(List<User> users, int low, int high){
        for(User u: users){
            if(low <= u.getAge() && u.getAge() < high){
                u.printUser();
            }
            else{
                System.out.println("No users found");
            }
        }
    }

    public static void printUsers(List<User> users, User.CheckUser tester){
        for(User u: users){
            if(tester.test(u)){
                u.printUser();
            }
        }
    }

    //Sorts user's usernames alphabetically
    static ArrayList<CompareUser> userNames = new ArrayList<CompareUser>();

    /**
     * space left for taking values and putting them into a database of usernames
     * */

    static void alphabetizeUser(){
        System.out.println("List of users presorted");
        for(int i = 0; i < userNames.size(); i++){
            System.out.println(userNames.get(i).getUserName());
            //print this to a screen that the user can interact to. probably on ui
        }
        System.out.println("---------");
        System.out.println("List of users sorted");
        Collections.sort(userNames);
        for(int i = 0; i<userNames.size();i++){
            System.out.println(userNames.get(i).getUserName());
        }
    }

    /** unused sorting things #### */

    //user login relations
    //find user's index within list which includes user's information.
    static int findUserIndex(String email){
        int i = 0;
        User temp = listOfUsers.get(i);
        while(temp.getEmail().equals(email)){
            i++;
        }
        return i;
    }

    static String checkAnswer(String email, String answer, String newPassword){
        int i = 0;
        try{
            i = findUserIndex(email);
        }catch (NullPointerException ne){
            System.out.println("User does not exist");
        }
        User temp = listOfUsers.get(i);
        if(answer.equals(temp.getSecretAnswer())){
            temp.setPassword(newPassword);
            System.out.println("pw updated");
            return "New password has been set";
        }else{
            System.out.println("answer incorrect");
            return "Answer is incorrect";
        }
    }


    static String convertBirthNumToString(int birthMonthNum, int birthdayNum, int birthYearNum) {
        String birthMonthString = birthMonthName[birthMonthNum - 1];
        String birthdayString = birthMonthString + " " + birthdayNum + " , " + birthYearNum;
        return birthdayString;
    }

    public void printUser() {
        System.out.println(this.toString());
    }

    public String returnUser(){
        return this.toString();
    }

    public static List<User> listOfUsers = new ArrayList<>();

    //initializes default users built into program. planning on having database re-upload users into this list.
    public static List<User> createUserList() {
        //List<User> users = new ArrayList<>();
        List<User> users = User.listOfUsers;

        users.add(new User(Type.PERSONAL,
                "AdminFirst", "AdminLast", "Admin@Email.com",
                "AdminPass", "AdminAnswer",
                100, 1234567890,
                01, 01, 2001));
        users.add(new User(Type.STUDENT,
                "StudentFirst","StudentLast","Student@Email.com",
                "StudentPass","StudentAnswer",
                200,1231231234,
                01,01,2001));
        users.add(new User(Type.TEACHER,
                "TeacherFirst","TeacherLast","Teacher@Email.com",
                "TeacherPass","TeacherAnswer",
                300,1230001230,
                01,01,2001));
        users.add(new User(Type.BUSINESS,
                "BusinessFirst","BusinessLast","Business@Email.com",
                "BusinessPass","BusinessAnswer",
                400,1234564567,
                01,01,2001));
        return users;
    }

    //creating username with @type user, this was just a test to see how to use lambdas.
    static String setUserName(String firstName, String lastName, int phoneNumber, Type typeUser) {
        String pnString = String.valueOf(phoneNumber);
        String lastFourOfPhoneNumber = pnString.substring(pnString.length() - 4);
        String userNameWOAT = firstName.charAt(0) + lastName + lastFourOfPhoneNumber;
        addAtFunction edu = (s) -> s + "@edu";
        addAtFunction bis = (s) -> s + "@bis";
        addAtFunction per = (s) -> s + "@per";
        String userName = null;
        switch(typeUser){
            case TEACHER:
            case STUDENT:
                userName = userNameFormatted(userNameWOAT, edu);
                break;
            case BUSINESS:
                userName = userNameFormatted(userNameWOAT, bis);
                break;
            case PERSONAL:
                userName = userNameFormatted(userNameWOAT, per);
                break;
        }
        return userName;
    }

    public static String userNameFormatted(String str, addAtFunction format){
        String result = format.returnUserName(str);
        return result;
    }
}
interface addAtFunction{
    String returnUserName(String str);
}
