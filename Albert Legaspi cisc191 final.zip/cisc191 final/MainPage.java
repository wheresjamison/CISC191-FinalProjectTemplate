public class MainPage{
/**
 -directory between user list and userprofile
 -displays user's information, including button to print out .txt file with their information
 - displays list of users
 - different sort buttons
 - page will refresh list of users organized by a criteria
*/

}
