import java.util.ArrayList;
import java.util.List;

public interface edu {
    List<String> courses = new ArrayList<>();
    void createFileOFAllCourses(String c1, String c2, String c3, String c4);
}
